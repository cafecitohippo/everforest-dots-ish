# This file was created by fish when upgrading to version 4.3, to migrate
# theme variables from universal to global scope.
# Don't edit this file, as it will be written by the web-config tool (`fish_config`).
# To customize your theme, delete this file and see
#     help interactive#syntax-highlighting
# or
#     man fish-interactive | less +/^SYNTAX.HIGHLIGHTING
# for appropriate commands to add to ~/.config/fish/config.fish instead.
# See also the release notes for fish 4.3.0 (run `help relnotes`).

set --global fish_color_autosuggestion 4c566a
set --global fish_color_cancel --reverse
set --global fish_color_command 88c0d0
set --global fish_color_comment 4c566a --italics
set --global fish_color_cwd 5e81ac
set --global fish_color_cwd_root bf616a
set --global fish_color_end 81a1c1
set --global fish_color_error bf616a
set --global fish_color_escape ebcb8b
set --global fish_color_history_current e5e9f0 --bold
set --global fish_color_host a3be8c
set --global fish_color_host_remote ebcb8b
set --global fish_color_keyword 81a1c1
set --global fish_color_normal normal
set --global fish_color_operator 81a1c1
set --global fish_color_option 8fbcbb
set --global fish_color_param d8dee9
set --global fish_color_quote a3be8c
set --global fish_color_redirection b48ead --bold
set --global fish_color_search_match --bold --background=434c5e
set --global fish_color_selection d8dee9 --bold --background=434c5e
set --global fish_color_status bf616a
set --global fish_color_user a3be8c
set --global fish_color_valid_path --underline=single
set --global fish_pager_color_background
set --global fish_pager_color_completion e5e9f0
set --global fish_pager_color_description ebcb8b --italics
set --global fish_pager_color_prefix normal --bold --underline=single
set --global fish_pager_color_progress 3b4252 --bold --background=d08770
set --global fish_pager_color_secondary_background
set --global fish_pager_color_secondary_completion
set --global fish_pager_color_secondary_description
set --global fish_pager_color_secondary_prefix
set --global fish_pager_color_selected_background --background=434c5e
set --global fish_pager_color_selected_completion
set --global fish_pager_color_selected_description
set --global fish_pager_color_selected_prefix
